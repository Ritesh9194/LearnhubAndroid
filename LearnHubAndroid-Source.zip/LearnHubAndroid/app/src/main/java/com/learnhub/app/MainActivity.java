package com.learnhub.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

/** Native LearnHub website shell with video fullscreen, refresh, navigation and offline handling. */
public class MainActivity extends AppCompatActivity {
    private WebView web;
    private SwipeRefreshLayout refresh;
    private FrameLayout root;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private WebChromeClient chromeClient;
    private String siteHost;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        root = new FrameLayout(this);
        refresh = new SwipeRefreshLayout(this);
        web = new WebView(this);
        refresh.addView(web, new ViewGroup.LayoutParams(-1, -1));
        root.addView(refresh, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        Uri home = Uri.parse(BuildConfig.SITE_URL);
        siteHost = home.getHost() == null ? "" : home.getHost().toLowerCase();

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setAllowFileAccess(false);
        settings.setSupportMultipleWindows(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        refresh.setOnRefreshListener(() -> web.reload());

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return routeUrl(request.getUrl());
            }

            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeUrl(Uri.parse(url));
            }

            private boolean routeUrl(Uri uri) {
                String host = uri.getHost();
                if (host == null) return false;
                host = host.toLowerCase();
                // Keep the configured site and YouTube pages/embeds in the app.
                if (isSiteHost(host) || host.equals("youtube.com") || host.endsWith(".youtube.com")
                        || host.equals("youtu.be") || host.endsWith(".youtube-nocookie.com")) return false;
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                } catch (Exception ignored) { }
                return true;
            }

            private boolean isSiteHost(String host) {
                return host.equals(siteHost) || (!siteHost.isEmpty() && host.endsWith("." + siteHost));
            }

            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                refresh.setRefreshing(true);
            }

            @Override public void onPageFinished(WebView view, String url) {
                refresh.setRefreshing(false);
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) showOfflinePage();
            }
        });

        chromeClient = new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view;
                customCallback = callback;
                root.addView(view, new FrameLayout.LayoutParams(-1, -1));
                refresh.setVisibility(View.GONE);
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }

            @Override
            public void onHideCustomView() { hideCustomView(); }
        };
        web.setWebChromeClient(chromeClient);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (customView != null) hideCustomView();
                else if (web.canGoBack()) web.goBack();
                else { setEnabled(false); getOnBackPressedDispatcher().onBackPressed(); }
            }
        });

        if (savedInstanceState != null) {
            if (web.restoreState(savedInstanceState) == null) web.loadUrl(BuildConfig.SITE_URL);
        } else web.loadUrl(BuildConfig.SITE_URL);
    }

    private void hideCustomView() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        if (customCallback != null) customCallback.onCustomViewHidden();
        customCallback = null;
        refresh.setVisibility(View.VISIBLE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    private void showOfflinePage() {
        refresh.setRefreshing(false);
        String html = "<html><body style='font-family:sans-serif;text-align:center;padding:48px 24px'>"
                + "<h2>You're offline</h2><p>Check your internet connection, then pull down to retry.</p>"
                + "<p><a href='" + BuildConfig.SITE_URL + "'>Try again</a></p></body></html>";
        web.loadDataWithBaseURL(BuildConfig.SITE_URL, html, "text/html", "UTF-8", null);
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }
    @Override protected void onPause() { if (web != null) web.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onDestroy() {
        if (web != null) { web.stopLoading(); web.setWebChromeClient(null); web.destroy(); }
        super.onDestroy();
    }
}
