# LearnHub Android app

This is a native Android WebView wrapper based on the supplied `MainActivity.java`.

## Included features
- Full-screen website display
- HTML5/YouTube video playback and immersive full-screen video
- Pull-to-refresh
- Android back navigation (and exit from full-screen video)
- Offline error page with retry link
- Configured website stays in the app; external links open in the phone's browser

## Important: set your website
The supplied Java file refers to `BuildConfig.SITE_URL`, but no actual website URL was included. The project therefore uses `https://example.com` as a safe placeholder. Replace `SITE_URL` in `gradle.properties` with your real HTTPS website before building. Also change the workflow's `-PSITE_URL=https://example.com` to the same URL if using GitHub Actions.

## Build APK using GitHub on an Android phone
1. Create/sign in to a GitHub account and create a new repository.
2. Upload the contents of this folder (not the ZIP itself) to the repository.
3. Edit `gradle.properties` and replace `https://example.com` with your website URL. Edit `.github/workflows/build-apk.yml` and replace the same placeholder there.
4. Open the repository's **Actions** tab, select **Build Android APK**, tap **Run workflow**, and wait for the workflow to finish.
5. Open the completed workflow run and download the **LearnHub-debug-apk** artifact. Extract it to obtain `app-debug.apk`.
6. Open the APK on your Android phone and allow installation from that source if Android asks.

A debug APK is for testing/sideloading. A Play Store release requires a separately signed release build.
